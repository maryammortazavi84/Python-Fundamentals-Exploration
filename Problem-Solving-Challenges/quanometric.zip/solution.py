def queranumeric(order: list[str], words: list[str]) -> list[str]:
    return []
